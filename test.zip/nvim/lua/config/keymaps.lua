vim.cmd.nmap 'j <LEFT>'
vim.cmd.nmap 'k <DOWN>'
vim.cmd.nmap 'l <UP>'
vim.cmd.nmap '; <RIGHT>'

vim.cmd.vmap 'j <LEFT>'
vim.cmd.vmap 'k <DOWN>'
vim.cmd.vmap 'l <UP>'
vim.cmd.vmap '; <RIGHT>'

local builtin = require('telescope.builtin')
vim.keymap.set('n', '<C-o>', builtin.find_files, { desc = 'Telescope find files' })
vim.keymap.set('n', '<leader>fg', builtin.live_grep, { desc = 'Telescope live grep' })
vim.keymap.set('n', '<leader>fb', builtin.buffers, { desc = 'Telescope buffers' })
vim.keymap.set('n', '<leader>fh', builtin.help_tags, { desc = 'Telescope help tags' })
