require('config.lazy')
require('config.keymaps')
require('config.options')
